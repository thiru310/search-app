-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: search_app
-- ------------------------------------------------------
-- Server version	5.7.31-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `replacement` int(11) DEFAULT NULL,
  `warrenty` int(11) DEFAULT NULL,
  `model_name` varchar(200) DEFAULT NULL,
  `available` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id_ref` (`category_id`),
  CONSTRAINT `category_id_ref` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,2,'ASUS TUF Gaming F15(2022)','ASUS',89000,7,1,'ASUS TUF Gaming',1),(2,2,'ASUS Vivo Book 14 (2021)','ASUS',52990,7,1,'ASUS VIVOBOOK 14',1),(3,2,'ASUS Vivo Book 15 (2021)','ASUS',26990,10,2,'ASUS VIVOBOOK 15',1),(4,2,'HP ChromeBook 14','HP',25990,6,3,'HP CHROMEBOOK',1),(5,2,'Lenovo IdeaPad Slim 3 11th Gen','Lenovo',35990,7,1,'Lenovo Ideapad',1),(6,2,'Lenovo IdeaPad Slim 3 10th Gen','Lenovo',33990,7,1,'Lenovo Ideapad',1),(7,2,'HP 247 G8 Laptop','HP',31999,7,1,'HP G8',1),(8,2,'Dell New Inspiron','Dell',42099,7,1,'Dell Inspiron',1),(9,1,'Apple IPad Air 2020','Apple',30999,10,1,'Apple IPad',1),(10,2,'Apple MacBook Pro','Apple',159999,10,2,'Apple Macbook',1),(11,1,'Samsung Galaxy Tab A7','Samsung',20000,10,1,'Samsung Galaxy',1),(12,1,'Lenovo Tab M8','Lenovo',18999,10,1,'Lenovo M8',1),(13,1,'Lenovo Tab M10','Lenovo',21999,10,1,'Lenovo M10',1),(14,1,'Lenovo Tab M7','Lenovo',16999,7,1,'Lenovo M7',1);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-28  4:50:53
