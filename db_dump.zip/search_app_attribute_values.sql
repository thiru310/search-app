-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: search_app
-- ------------------------------------------------------
-- Server version	5.7.31-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attribute_values`
--

DROP TABLE IF EXISTS `attribute_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attribute_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_name_id` int(11) DEFAULT NULL,
  `value` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `attribute_name_id_idx` (`attribute_name_id`),
  CONSTRAINT `attribute_name_id` FOREIGN KEY (`attribute_name_id`) REFERENCES `attribute_name` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attribute_values`
--

LOCK TABLES `attribute_values` WRITE;
/*!40000 ALTER TABLE `attribute_values` DISABLE KEYS */;
INSERT INTO `attribute_values` VALUES (1,1,'8gb'),(2,1,'4gb'),(3,1,'16gb'),(4,1,'32gb'),(5,2,'13.3inch'),(6,2,'13.9inch'),(7,2,'14inch'),(8,2,'15inch'),(9,2,'15.6inch'),(10,3,'Bluetooth'),(11,3,'Wifi'),(12,3,'Cellular'),(13,3,'NFC'),(14,4,'LCD'),(15,4,'LED'),(16,4,'OLED'),(17,4,'TouchScreen'),(18,5,'Intel I3'),(19,5,'Intel I5'),(20,5,'Intel I7'),(21,5,'AMD Ryzen 3'),(22,5,'AMD Ryzen 5'),(23,5,'AMD Ryzen 7'),(24,6,'Intel'),(25,6,'Adreno'),(26,6,'MSI'),(27,6,'NVIDIA'),(28,7,'3 Generation'),(29,7,'5 Generation'),(30,7,'10 Generation'),(31,7,'11 Generation'),(32,8,'Red'),(33,8,'Silver'),(34,8,'Black'),(35,8,'White'),(36,8,'Blue'),(37,9,'Intel'),(38,9,'MSI'),(39,9,'NVIDIA'),(40,10,'16Hrs'),(41,10,'10Hrs'),(42,10,'24Hrs'),(43,11,'Intel'),(44,11,'Apple'),(45,11,'AMD');
/*!40000 ALTER TABLE `attribute_values` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-28  4:50:52
